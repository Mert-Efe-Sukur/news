const Alexa = require('ask-sdk-core');
const RSSParser = require('rss-parser');

const parser = new RSSParser();

const FeedHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'LaunchRequest' ||
               Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest' &&
               Alexa.getIntentName(handlerInput.requestEnvelope) === 'GetNewsIntent';
    },
    async handle(handlerInput) {
        const newsFeeds = [
            'https://www.nature.com/nature.rss'        ];
        const numItems = 3;  // Number of news items to fetch from each feed
        
        let news = '';
        for (let feedUrl of newsFeeds) {
            try {
                const feed = await parser.parseURL(feedUrl);
                const items = feed.items.slice(0, numItems);
                news += `Here are the top ${numItems} news from ${feed.title}: `;
                items.forEach((item, index) => {
                    news += `${index + 1}. ${item.title}. `;
                });
                news += ' ';
            } catch (error) {
                console.error(`Failed to parse feed from ${feedUrl}: ${error.message}`);
                news += `Sorry, there was a problem fetching the news from ${feedUrl}. `;
            }
        }

        const speakOutput = news || 'Sorry, I could not find any news at the moment.';
        
        return handlerInput.responseBuilder
            .speak(speakOutput)
            .getResponse();
    }
};

exports.handler = Alexa.SkillBuilders.custom()
    .addRequestHandlers(FeedHandler)
    .lambda();
